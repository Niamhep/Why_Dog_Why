﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class animation : MonoBehaviour
{
    private float speed = 2f;

    public float wSpeed;
    public float rSpeed;
    public float rotSpeed;
    float z;

    static Animator anim;

    // Use this for initialization
    void Start()
    {
        anim = GetComponent<Animator>();

    }

    // Update is called once per frame
    void Update()
    {
        //if (Input.GetKeyDown(KeyCode.A)) 
        //{
        //    anim.SetBool("isWalking", true);
        //    anim.SetFloat("Speed", z);
        //}
        //else
        //{
        //    anim.SetBool("isWalking", false);
        //}



        z = Input.GetAxis("Horizontal");
        z = Mathf.Clamp01(z);
        anim.SetFloat("Speed", z);
        float y = Input.GetAxis("Vertical") * rotSpeed;

        transform.Translate(0, 0, z/7); 
        transform.Rotate(0, y, 0);

    }
}
